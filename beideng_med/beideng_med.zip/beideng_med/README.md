# beideng_med
front-end of a medical website for SHU summer classwork
